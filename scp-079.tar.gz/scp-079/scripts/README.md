# Scripts

This repo stores some scripts.

## Contribution

Contributions are always welcome, whether it's modifying source code to add new features or bug fixes, documenting new file formats or simply editing some grammar.

You can also join the [discuss group](https://t.me/SCP_079_CHAT) if you are unsure of anything.

## License

Licensed under the terms of the [GNU General Public License v3](LICENSE).
