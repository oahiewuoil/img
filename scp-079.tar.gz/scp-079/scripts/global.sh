#!/bin/bash

cd ~/scp-079/scripts || exit
vim config.ini
